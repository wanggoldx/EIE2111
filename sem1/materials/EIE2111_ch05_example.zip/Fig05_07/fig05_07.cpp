// Fig. 5.11: fig05_11.cpp
// do...while repetition statement.
#include <iostream>
using std::cout;
using std::endl;

int main()
{
   int counter = 1; // initialize counter

   do 
   {
      cout << counter << " "; // display counter
      counter++; // increment counter
   } while ( counter <= 10 ); // end do...while 

   cout << endl; // output a newline
   return 0; // indicate successful termination
} // end main




/**************************************************************************
 * (C) Copyright 1992-2005 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
